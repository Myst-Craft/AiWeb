import tkinter as tk
import random

class RockPaperScissorsGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Rock Paper Scissors")
        self.root.geometry("720x1280")  # 9:16 aspect ratio for 720p

        # Initial Player Scores
        self.player_score = 0
        self.ai_score = 0
        self.rounds_played = 0
        self.game_stage = "easy"  # Start with Easy AI
        self.attempts_to_reach_boss = 0  # Counter for attempts to reach the boss
        self.boss_defeats = 0  # Counter for how many times the player beat the boss
        self.attempts_list = []  # List to keep track of attempts to kill the boss
        self.least_attempts_to_kill_boss = []  # To track the least attempts

        # Create canvas for custom layout
        self.canvas = tk.Canvas(self.root, width=720, height=1280)
        self.canvas.pack()

        # Labels to display score
        self.score_label = tk.Label(self.root, text="Player: 0 | AI: 0", font=("Arial", 14))
        self.canvas.create_window(360, 50, window=self.score_label)

        # Result display
        self.result_label = tk.Label(self.root, text="Make your choice!", font=("Arial", 18))
        self.canvas.create_window(360, 120, window=self.result_label)

        # Divider line in the middle
        self.canvas.create_line(360, 0, 360, 1200, fill="black", width=2)

        # Player 1 side (Left)
        self.player_icon_label = tk.Label(self.root, text="👤", font=("Arial", 50))
        self.canvas.create_window(180, 400, window=self.player_icon_label)

        self.player_name_label = tk.Label(self.root, text="Player 1", font=("Arial", 16))
        self.canvas.create_window(180, 460, window=self.player_name_label)

        # AI Player side (Right)
        self.ai_icon_label = tk.Label(self.root, text="🤖", font=("Arial", 50))
        self.canvas.create_window(540, 400, window=self.ai_icon_label)

        self.ai_name_label = tk.Label(self.root, text="AI Player", font=("Arial", 16))
        self.canvas.create_window(540, 460, window=self.ai_name_label)

        # "Vs" Icon in the middle
        self.vs_label = tk.Label(self.root, text="VS", font=("Arial", 50, "bold"), fg="red")
        self.canvas.create_window(360, 400, window=self.vs_label)

        # Buttons for the user to click (Rock, Paper, Scissors)
        self.rock_button = tk.Button(self.root, text="Rock", width=12, height=2, command=lambda: self.player_turn("rock"))
        self.canvas.create_window(180, 600, window=self.rock_button)

        self.paper_button = tk.Button(self.root, text="Paper", width=12, height=2, command=lambda: self.player_turn("paper"))
        self.canvas.create_window(360, 600, window=self.paper_button)

        self.scissors_button = tk.Button(self.root, text="Scissors", width=12, height=2, command=lambda: self.player_turn("scissors"))
        self.canvas.create_window(540, 600, window=self.scissors_button)

        # Player's and AI's choices display
        self.player_choice_label = tk.Label(self.root, text="Your choice: ", font=("Arial", 14))
        self.canvas.create_window(180, 700, window=self.player_choice_label)

        self.ai_choice_label = tk.Label(self.root, text="AI's choice: ", font=("Arial", 14))
        self.canvas.create_window(540, 700, window=self.ai_choice_label)

        # Info Section: AI Difficulty and Points Info (at the bottom left)
        self.info_frame = tk.Frame(self.root, bg="#f0f0f0", relief="solid", bd=2)
        self.info_frame.place(x=0, y=800, relwidth=0.5, relheight=0.2)  # Left side of the screen

        # Label for the AI Difficulty Info Box
        self.info_label = tk.Label(self.info_frame, text="AI Difficulty Info", font=("Arial", 18, "bold"))
        self.info_label.grid(row=0, column=0, columnspan=2, pady=10)

        # Labels for the difficulty information
        self.difficulty_label = tk.Label(self.info_frame, text=f"Difficulty: {self.game_stage.capitalize()}", font=("Arial", 12))
        self.difficulty_label.grid(row=1, column=0, columnspan=2, sticky="n", pady=5)

        self.points_label = tk.Label(self.info_frame, text="Points for Boss: 20", font=("Arial", 12))
        self.points_label.grid(row=2, column=0, columnspan=2, sticky="n", pady=5)

        self.explanation_label = tk.Label(self.info_frame, text="Easy: Random\nMedium: Slightly smarter\nBoss: Unbeatable", font=("Arial", 12))
        self.explanation_label.grid(row=3, column=0, columnspan=2, sticky="n", pady=5)

        # Information about difficulty transitions
        self.transition_info_label = tk.Label(self.info_frame, text="Reach 10 points to face Medium AI\nReach 20 points for the Boss!", font=("Arial", 10))
        self.transition_info_label.grid(row=4, column=0, columnspan=2, sticky="n", pady=5)

        # Least attempts to kill the boss (New section on the right, aligned with AI difficulty section)
        self.attempts_section_label = tk.Label(self.root, text="Least Attempts to Kill the Boss", font=("Arial", 12, "bold"))
        self.attempts_section_label.place(x=360, y=800)  # Move it to align with the AI difficulty section

        self.attempts_list_label = tk.Label(self.root, text="No attempts yet.", font=("Arial", 12), anchor="w", justify="left")
        self.attempts_list_label.place(x=360, y=820)  # Move it slightly below the section label

        # Top-right sections (Attempts to reach Boss and Boss Defeats)
        self.attempts_frame = tk.Frame(self.root, bg="#f0f0f0", relief="solid", bd=2)
        self.attempts_frame.place(x=500, y=50, width=200, height=150)

        self.attempts_to_boss_label = tk.Label(self.attempts_frame, text="Attempts to reach Boss", font=("Arial", 12, "bold"))
        self.attempts_to_boss_label.grid(row=0, column=0, sticky="w")

        self.attempts_counter_label = tk.Label(self.attempts_frame, text="0", font=("Arial", 14))
        self.attempts_counter_label.grid(row=1, column=0)

        self.boss_defeats_label = tk.Label(self.attempts_frame, text="Boss Defeats", font=("Arial", 12, "bold"))
        self.boss_defeats_label.grid(row=2, column=0, sticky="w")

        self.boss_defeats_counter_label = tk.Label(self.attempts_frame, text="0", font=("Arial", 14))
        self.boss_defeats_counter_label.grid(row=3, column=0)

    def player_turn(self, player_choice):
        # Get AI's choice based on difficulty level
        ai_choice = self.get_ai_choice()

        # Update labels with choices
        self.player_choice_label.config(text=f"Your choice: {self.format_choice(player_choice)}")
        self.ai_choice_label.config(text=f"AI's choice: {self.format_choice(ai_choice)}")

        # Determine winner
        result = self.check_winner(player_choice, ai_choice)

        # Update result label
        self.result_label.config(text=result)

        # Update scores
        if result == "You win!":
            self.player_score += 1
        elif result == "AI wins!":
            self.ai_score += 1

        # Update score display
        self.score_label.config(text=f"Player: {self.player_score} | AI: {self.ai_score}")

        # Check if Player has reached the required points to move to next AI stage
        if self.player_score == 10 and self.game_stage == "easy":
            self.game_stage = "medium"
            self.difficulty_label.config(text=f"Difficulty: {self.game_stage.capitalize()}")
            self.result_label.config(text="You defeated Easy AI! Now face Medium AI!")
            self.attempts_to_reach_boss += 1
        elif self.player_score == 20 and self.game_stage == "medium":
            self.game_stage = "boss"
            self.difficulty_label.config(text=f"Difficulty: {self.game_stage.capitalize()}")
            self.result_label.config(text="You defeated Medium AI! Now face the Boss!")
            self.attempts_to_reach_boss += 1
        elif self.game_stage == "boss" and result == "You win!":
            self.boss_defeats += 1
            self.attempts_list.append((self.attempts_to_reach_boss, self.ai_score))
            self.attempts_list_label.config(text="\n".join([f"Player: {x[0]}, AI: {x[1]}" for x in sorted(self.attempts_list)]))
            self.attempts_to_reach_boss = 0  # Reset attempts to reach the boss
            self.player_score = 0  # Reset player score
            self.ai_score = 0  # Reset AI score
            self.update_attempts_counter()

    def update_attempts_counter(self):
        self.attempts_counter_label.config(text=str(self.attempts_to_reach_boss))
        self.boss_defeats_counter_label.config(text=str(self.boss_defeats))

    def get_ai_choice(self):
        if self.game_stage == "easy":
            return random.choice(["rock", "paper", "scissors"])
        elif self.game_stage == "medium":
            return self.medium_ai_choice()
        else:
            return self.boss_ai_choice()

    def medium_ai_choice(self):
        return random.choice(["rock", "paper", "scissors"])

    def boss_ai_choice(self):
        return "rock" if self.player_score % 3 == 0 else "paper" if self.player_score % 3 == 1 else "scissors"

    def check_winner(self, player, ai):
        if player == ai:
            return "It's a draw!"
        elif (player == "rock" and ai == "scissors") or \
             (player == "paper" and ai == "rock") or \
             (player == "scissors" and ai == "paper"):
            return "You win!"
        else:
            return "AI wins!"

    def format_choice(self, choice):
        if choice == "rock":
            return "Rock 🪨"
        elif choice == "paper":
            return "Paper 📄"
        elif choice == "scissors":
            return "Scissors ✂️"


if __name__ == "__main__":
    root = tk.Tk()
    game = RockPaperScissorsGame(root)
    root.mainloop()

import random
import tkinter as tk


class MathGame:
    def __init__(self, root, difficulty):
        self.root = root
        self.root.title("Python Math Game")
        self.root.geometry("1920x1080")  # Fixed window size

        # Global font size for consistency
        self.font_size = 24
        self.button_font_size = 18

        self.score = 0
        self.total_questions = 0
        self.difficulty = difficulty

        self.label_welcome = tk.Label(root, text="Welcome to the Python Math Game!", font=("Helvetica", self.font_size))
        self.label_welcome.pack(pady=10)

        self.label_instructions = tk.Label(root, text="Answer the questions correctly or type 'quit' to exit.", font=("Helvetica", self.font_size))
        self.label_instructions.pack(pady=10)

        self.label_question = tk.Label(root, text="", font=("Helvetica", self.font_size))
        self.label_question.pack(pady=20)

        self.entry_answer = tk.Entry(root, font=("Helvetica", self.font_size))
        self.entry_answer.pack(pady=10)
        self.entry_answer.bind("<Return>", self.submit_answer)

        self.label_feedback = tk.Label(root, text="", font=("Helvetica", self.font_size))
        self.label_feedback.pack(pady=20)

        self.label_score = tk.Label(root, text="Score: 0", font=("Helvetica", self.font_size))
        self.label_score.pack(pady=10)

        # Keybindings instruction label
        self.label_keybinds = tk.Label(root, text="Key Bindings: \n- Space: Next Question\n- Enter: Submit Answer\n- M: Go to Menu", font=("Helvetica", self.font_size))
        self.label_keybinds.pack(pady=10)

        # Buttons for next question and quit
        self.button_next = tk.Button(root, text="Next Question", command=self.next_question, font=("Helvetica", self.button_font_size))
        self.button_next.pack(side="left", padx=10, pady=20)

        self.quit_button = self.create_quit_button()  # Custom quit button
        self.quit_button.pack(side="bottom", pady=20)

        # Bind keys to actions
        self.root.bind("<space>", self.next_question_event)
        self.root.bind("<Return>", self.submit_answer)
        self.root.bind("m", self.go_to_menu_event)  # Go to menu on pressing 'M'

        self.current_question = None
        self.correct_answer = None

        self.next_question()

    def ask_question(self):
        operations = ['+', '-', '*', '/']
        num1 = random.randint(1, 20)
        num2 = random.randint(1, 20)
        operation = random.choice(operations)

        if operation == '/':
            num1 = num1 * num2

        question = f"What is {num1} {operation} {num2}?"

        if operation == '+':
            correct_answer = num1 + num2
        elif operation == '-':
            correct_answer = num1 - num2
        elif operation == '*':
            correct_answer = num1 * num2
        elif operation == '/':
            correct_answer = num1 // num2

        return question, correct_answer

    def next_question(self):
        self.current_question, self.correct_answer = self.ask_question()
        self.label_question.config(text=self.current_question)
        self.label_feedback.config(text="")
        self.entry_answer.delete(0, tk.END)

    def next_question_event(self, event=None):
        self.next_question()

    def submit_answer(self, event=None):
        self.check_answer()

    def check_answer(self, event=None):
        user_input = self.entry_answer.get()

        if user_input.lower() == 'quit':
            self.quit_game()
            return
        try:
            user_answer = int(user_input)
            if user_answer == self.correct_answer:
                self.label_feedback.config(text="Correct! Well done.", fg="green")
                self.score += 1
            else:
                self.label_feedback.config(text="Wrong, better luck next time!", fg="red")
                self.score = 0
        except ValueError:
            self.label_feedback.config(text="Please enter a valid number.", fg="red")

        self.total_questions += 1
        self.label_score.config(text=f"Score: {self.score}")

    def quit_game(self):
        print("Quitting the game...")
        self.root.quit()

    def go_to_menu_event(self, event=None):
        self.go_to_menu()

    def go_to_menu(self):
        self.clear_game_screen()
        self.show_menu()

    def clear_game_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def create_quit_button(self):
        quit_button = tk.Button(self.root, text="X", command=self.quit_game, font=("Helvetica", self.button_font_size),
                                width=4, height=2, fg="white", bg="red", relief="solid", bd=3, highlightthickness=0)
        quit_button.config(command=self.quit_game)
        quit_button.place(x=960 - 50, y=1040 - 50, anchor='center')  # Centered at the bottom
        return quit_button

    def show_menu(self):
        menu_screen = MenuScreen(self.root)
        menu_screen.show_menu()


class MenuScreen:
    def __init__(self, master):
        self.master = master
        self.master.geometry("1920x1080")  # Fixed window size
        self.master.title("Python Math Game - Menu")

        # Global font size for consistency
        self.font_size = 24
        self.button_font_size = 18

        self.menu_frame = tk.Frame(self.master)
        self.menu_frame.pack(fill=tk.BOTH, expand=True)

        self.label_welcome = tk.Label(self.menu_frame, text="Welcome to the Python Math Game!", font=("Helvetica", self.font_size))
        self.label_welcome.pack(pady=10)

        # Start button
        self.button_start = tk.Button(self.menu_frame, text="Start Game", command=self.start_game, font=("Helvetica", self.button_font_size))
        self.button_start.pack(pady=10)

        # Quit button
        self.button_quit = tk.Button(self.menu_frame, text="Quit", command=self.quit_game, font=("Helvetica", self.button_font_size))
        self.button_quit.pack(pady=10)

        # Difficulty menu
        self.difficulty_var = tk.StringVar(value="Easy")
        self.difficulty_options = ["Easy", "Medium", "Hard", "Very Hard"]
        self.difficulty_menu = tk.OptionMenu(self.menu_frame, self.difficulty_var, *self.difficulty_options)
        self.difficulty_menu.pack(pady=10)

        # Key Bindings display
        self.label_keybinds = tk.Label(self.menu_frame, text="Key Bindings: \n- Space: Start Game\n- M: Go to Menu\n- Q: Quit", font=("Helvetica", self.font_size))
        self.label_keybinds.pack(pady=10)

        # Bind key events for Quit and Start
        self.master.bind("q", self.quit_game_event)
        self.master.bind("m", self.go_to_menu_event)

    def start_game(self):
        difficulty = self.difficulty_var.get()
        self.clear_menu()
        self.show_loading_screen(difficulty)

    def quit_game(self):
        self.master.quit()

    def quit_game_event(self, event=None):
        self.quit_game()

    def go_to_menu_event(self, event=None):
        self.go_to_menu()

    def clear_menu(self):
        # Properly clear all widgets in the menu screen
        for widget in self.menu_frame.winfo_children():
            widget.destroy()

    def show_loading_screen(self, difficulty):
        # Show the loading screen message
        loading_label = tk.Label(self.master, text="Loading... Please Wait", font=("Helvetica", self.font_size))
        loading_label.pack(pady=10)
        self.master.after(2000, lambda: self.start_game_frame(difficulty))  # Show the game frame after 2 seconds

    def start_game_frame(self, difficulty):
        # Remove the loading screen and start the game
        for widget in self.master.winfo_children():
            widget.destroy()
        game = MathGame(self.master, difficulty)

    def show_menu(self):
        # Initialize the menu screen on the main window
        self.master.geometry("1920x1080")  # Ensure the window size is correct
        self.master.mainloop()


if __name__ == "__main__":
    root = tk.Tk()
    menu_screen = MenuScreen(root)
    menu_screen.show_menu()
